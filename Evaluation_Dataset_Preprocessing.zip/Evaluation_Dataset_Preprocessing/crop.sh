#!/bin/bash
# Google Gemini helped with the initial code here

# =====================================================================
# ========================= USER VARIABLES ============================
# =====================================================================

FOLDERS=("sleepy" "awake")


OUTPUT_SIZE_W=640
OUTPUT_SIZE_H=640

ZOOM_FACTOR="1"

CROP_X_OFFSET=700
CROP_Y_OFFSET=360

# =====================================================================
# ========================= SCRIPT START ==============================
# =====================================================================

for DIR in "${FOLDERS[@]}"; do
    [ ! -d "$DIR" ] && echo "Folder '$DIR' not found. Skipping..." && continue

    echo "======================================"
    echo "Processing folder: $DIR"
    echo "======================================"

    for FILE in "$DIR"/*.mp4; do
        [ -e "$FILE" ] || continue

        FILENAME=$(basename "$FILE")
        OUTPUT_FILE="$DIR/cropped_$FILENAME"

        echo "Processing $FILE with Zoom Factor: $ZOOM_FACTOR..."

        ffmpeg -y -i "$FILE" \
            -vf "scale=iw*${ZOOM_FACTOR}:ih*${ZOOM_FACTOR},crop=${OUTPUT_SIZE_W}:${OUTPUT_SIZE_H}:${CROP_X_OFFSET}:${CROP_Y_OFFSET}" \
            -c:v libx264 -crf 18 -c:a copy "$OUTPUT_FILE"

        echo "Finished: $OUTPUT_FILE"
        echo "--------------------------------------"
    done
done

echo "All videos processed successfully!"
